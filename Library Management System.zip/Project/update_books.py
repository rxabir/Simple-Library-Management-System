from view_all_books import view_all_books
from save_all_books import save_all_books

def update_books(all_books):
    view_all_books(all_books)
    a = int(input("Enter the number of book which you  want to update: ")) -1
    if a < len(all_books):
        book = all_books[a]
        book['title'] = input("Enter New Book Title: ")
        book['author'] = input("Enter New Author Name: ")
        book['isbn'] = int(input("Enter New ISBN Number: "))
        book['year'] = int(input("Enter New Publishing Year Number: "))
        book['price'] = int(input("Enter New Book Price: "))
        book['quantity'] = int(input("Enter New Quantity Number: "))
        save_all_books(all_books)
        print("Book has been successfully updated")
    else:
        print("Try again with valid inputs.")
    return all_books